import React from 'react';
import { RISK_GROUPS, SIZE_STYLES } from '../constants';
import { RiskGroupId, RiskSize } from '../types';

interface RiskCircleProps {
  group: RiskGroupId;
  size?: RiskSize;
  className?: string;
}

export const RiskCircle: React.FC<RiskCircleProps> = ({ group, size = 'Pequeno', className = '' }) => {
  const sizeClass = SIZE_STYLES[size] || SIZE_STYLES['Pequeno'];
  const groupDef = RISK_GROUPS[group];
  const colorClass = groupDef?.color || 'bg-gray-400';
  
  return (
    <div 
      className={`rounded-full ${colorClass} ${sizeClass} shadow-sm border-2 border-white ring-1 ring-gray-200 flex-shrink-0 transition-transform hover:scale-110 ${className}`} 
      title={`${groupDef?.label} - Risco ${size}`} 
      aria-label={`${groupDef?.label} - ${size}`}
    />
  );
};
