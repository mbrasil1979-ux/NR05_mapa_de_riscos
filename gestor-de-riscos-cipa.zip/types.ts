import { Timestamp } from 'firebase/firestore';

export type RiskGroupId = 'fisico' | 'quimico' | 'biologico' | 'ergonomico' | 'acidente';
export type Frequency = 'Baixa' | 'Média' | 'Alta';
export type Severity = 'Leve' | 'Moderada' | 'Grave';
export type RiskSize = 'Pequeno' | 'Médio' | 'Grande';

export interface RiskGroupDef {
  id: RiskGroupId;
  label: string;
  color: string;
  text: string;
  border: string;
  hex: string;
  iconColor: string;
  description?: string;
  examples?: string[];
  psychosocial?: string[];
}

export interface AssessmentData {
  id?: string;
  sector: string;
  description: string;
  riskGroup: RiskGroupId;
  frequency: Frequency;
  severity: Severity;
  controls: string;
  responsible: string;
  riskSize?: RiskSize;
  createdAt?: Timestamp | any;
  userId?: string;
  status?: string;
}

export interface GuideSection {
  id: RiskGroupId;
  title: string;
  colorClass: string;
  iconColor: string;
  description: string;
  examples: string[];
  psychosocial?: string[];
}
