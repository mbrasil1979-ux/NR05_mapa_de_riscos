import { GoogleGenAI, Type } from "@google/genai";
import { RiskGroupId } from "../types";

// Access API Key safely
const apiKey = process.env.API_KEY || '';

let ai: GoogleGenAI | null = null;
if (apiKey) {
  ai = new GoogleGenAI({ apiKey });
}

export const suggestControlMeasures = async (
  description: string, 
  sector: string, 
  riskGroup: RiskGroupId
): Promise<string> => {
  
  if (!ai) {
    console.warn("Gemini API key is not set.");
    return "Sugestões de IA indisponíveis: Chave de API ausente.";
  }

  try {
    const prompt = `
      Como um Engenheiro de Segurança do Trabalho Sênior (especialista em NR-05), sugira 3 medidas de controle específicas e acionáveis para o seguinte risco no ambiente de trabalho:
      
      Setor: ${sector}
      Grupo de Risco: ${riskGroup}
      Descrição: ${description}
      
      Mantenha as sugestões concisas (máximo de 1 frase cada). Formate como uma lista com marcadores.
    `;

    const response = await ai.models.generateContent({
      model: 'gemini-2.5-flash',
      contents: prompt,
    });

    return response.text || "Nenhuma sugestão gerada.";
  } catch (error) {
    console.error("Gemini API Error:", error);
    return "Erro ao conectar ao serviço de IA.";
  }
};