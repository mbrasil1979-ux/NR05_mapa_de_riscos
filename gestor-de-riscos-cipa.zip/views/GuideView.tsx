import React from 'react';
import { BookOpen, Info, BrainCircuit } from 'lucide-react';
import { RISK_GUIDE_DATA } from '../constants';

export const GuideView: React.FC = () => (
  <div className="max-w-6xl mx-auto animate-fadeIn">
    <div className="mb-8">
      <h2 className="text-3xl font-bold text-slate-800 flex items-center gap-3">
        <BookOpen className="text-indigo-600" /> Guia de Classificação de Riscos
      </h2>
      <p className="text-slate-500 text-base mt-2 max-w-2xl">
        Manual de referência para identificação de perigos e classificação correta conforme normas NR-05.
      </p>
    </div>

    <div className="mb-8 bg-gradient-to-br from-white to-slate-50 rounded-xl border border-slate-200 shadow-sm p-6 md:p-8">
      <h3 className="text-lg font-bold text-slate-800 mb-6 flex items-center gap-2">
          <Info className="text-indigo-500" size={20}/>
          Critérios de Classificação
      </h3>
      <div className="grid grid-cols-1 md:grid-cols-2 gap-8 md:gap-12">
          <div>
              <h4 className="text-xs font-bold text-indigo-900 uppercase tracking-widest mb-4 border-b border-indigo-100 pb-2">Frequência (Exposição)</h4>
              <ul className="space-y-4">
                  <li className="flex gap-4">
                      <div className="w-2 h-2 rounded-full bg-indigo-300 mt-2 shrink-0"></div>
                      <div>
                        <span className="font-bold text-slate-700 block">Baixa</span>
                        <span className="text-sm text-slate-500 leading-relaxed">Ocorre raramente, eventualmente ou por períodos muito curtos (Ex: Manutenções anuais).</span>
                      </div>
                  </li>
                  <li className="flex gap-4">
                      <div className="w-2 h-2 rounded-full bg-indigo-500 mt-2 shrink-0"></div>
                      <div>
                        <span className="font-bold text-slate-700 block">Média</span>
                        <span className="text-sm text-slate-500 leading-relaxed">Ocorre algumas vezes na semana ou de forma intermitente (Ex: Metade da jornada).</span>
                      </div>
                  </li>
                  <li className="flex gap-4">
                      <div className="w-2 h-2 rounded-full bg-indigo-700 mt-2 shrink-0"></div>
                      <div>
                        <span className="font-bold text-slate-700 block">Alta</span>
                        <span className="text-sm text-slate-500 leading-relaxed">Exposição contínua, diária, permanente ou habitual.</span>
                      </div>
                  </li>
              </ul>
          </div>

          <div>
              <h4 className="text-xs font-bold text-red-900 uppercase tracking-widest mb-4 border-b border-red-100 pb-2">Gravidade (Potencial de Dano)</h4>
              <ul className="space-y-4">
                  <li className="flex gap-4">
                      <div className="w-2 h-2 rounded-full bg-red-300 mt-2 shrink-0"></div>
                      <div>
                        <span className="font-bold text-red-800 block">Leve</span>
                        <span className="text-sm text-slate-500 leading-relaxed">Lesões superficiais, irritação. Não requer afastamento do trabalho.</span>
                      </div>
                  </li>
                  <li className="flex gap-4">
                      <div className="w-2 h-2 rounded-full bg-red-500 mt-2 shrink-0"></div>
                      <div>
                        <span className="font-bold text-red-800 block">Moderada</span>
                        <span className="text-sm text-slate-500 leading-relaxed">Afastamento temporário. Danos reversíveis (Ex: Cortes profundos, fraturas simples).</span>
                      </div>
                  </li>
                  <li className="flex gap-4">
                      <div className="w-2 h-2 rounded-full bg-red-700 mt-2 shrink-0"></div>
                      <div>
                        <span className="font-bold text-red-800 block">Grave</span>
                        <span className="text-sm text-slate-500 leading-relaxed">Risco de morte, invalidez permanente, amputação ou doenças crônicas incuráveis.</span>
                      </div>
                  </li>
              </ul>
          </div>
      </div>
    </div>

    <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 pb-12">
      {RISK_GUIDE_DATA.map((group) => (
        <div key={group.id} className={`rounded-xl border flex flex-col transition-all hover:shadow-md ${group.id === 'ergonomico' ? 'border-yellow-400 shadow-sm ring-1 ring-yellow-200 bg-yellow-50/30' : 'border-slate-200 bg-white'}`}>
          <div className={`p-5 flex items-center gap-4 border-b ${group.colorClass} bg-opacity-30`}>
            <div className={`w-10 h-10 rounded-full ${group.iconColor} flex items-center justify-center text-white font-bold shadow-sm ring-2 ring-white`}>
               {group.id.charAt(0).toUpperCase()}
            </div>
            <div>
              <h3 className="font-bold text-lg">{group.title}</h3>
              <p className="text-sm opacity-90">{group.description}</p>
            </div>
          </div>

          <div className="p-6 flex-1 bg-white rounded-b-xl">
            <h4 className="text-xs font-bold uppercase text-slate-400 mb-4 tracking-wider">Exemplos Comuns</h4>
            <ul className="grid grid-cols-1 sm:grid-cols-2 gap-x-4 gap-y-2 mb-4">
              {group.examples.map((ex, i) => (
                <li key={i} className="flex items-start gap-2 text-sm text-slate-600">
                  <span className="block w-1.5 h-1.5 mt-1.5 rounded-full bg-slate-300 flex-shrink-0"></span>
                  {ex}
                </li>
              ))}
            </ul>

            {group.psychosocial && (
              <div className="mt-6 bg-indigo-50 rounded-lg p-4 border border-indigo-100">
                <h4 className="text-sm font-bold text-indigo-800 flex items-center gap-2 mb-2">
                  <BrainCircuit size={16} />
                  Fatores Psicossociais
                </h4>
                <ul className="flex flex-wrap gap-2 mt-3">
                  {group.psychosocial.map((psy, i) => (
                    <li key={i} className="text-xs font-medium text-indigo-700 bg-white px-3 py-1.5 rounded-full border border-indigo-100 shadow-sm">
                      {psy}
                    </li>
                  ))}
                </ul>
              </div>
            )}
          </div>
        </div>
      ))}
    </div>
  </div>
);