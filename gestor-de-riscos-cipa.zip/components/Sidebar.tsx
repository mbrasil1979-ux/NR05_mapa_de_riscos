import React from 'react';
import { AlertTriangle, LayoutDashboard, PlusCircle, BookOpen, FileText } from 'lucide-react';

interface SidebarProps {
  view: string;
  setView: (view: string) => void;
}

export const Sidebar: React.FC<SidebarProps> = ({ view, setView }) => {
  const menuItems = [
    { id: 'dashboard', label: 'Painel', icon: LayoutDashboard },
    { id: 'new', label: 'Novo Risco', icon: PlusCircle },
    { id: 'guide', label: 'Guia', icon: BookOpen },
    { id: 'report', label: 'Relatórios', icon: FileText },
  ];

  return (
    <aside className="w-20 md:w-64 bg-slate-900 text-white flex flex-col fixed md:relative h-full z-50 shadow-xl transition-all no-print">
      <div className="p-4 md:p-6 border-b border-slate-800 flex items-center gap-3">
        <div className="bg-gradient-to-tr from-indigo-600 to-indigo-400 p-2 rounded-lg shadow-lg shadow-indigo-500/30">
          <AlertTriangle size={24} className="text-white" />
        </div>
        <h1 className="text-xl font-bold hidden md:block tracking-tight text-white">
          CIPA <span className="text-indigo-400">Gestor</span>
        </h1>
      </div>
      
      <nav className="flex-1 p-4 space-y-2">
        {menuItems.map((item) => (
          <button 
            key={item.id}
            onClick={() => setView(item.id)}
            className={`w-full flex items-center gap-3 px-4 py-3.5 rounded-xl transition-all duration-200 group ${
              view === item.id 
                ? 'bg-indigo-600 text-white shadow-lg shadow-indigo-900/50' 
                : 'text-slate-400 hover:bg-slate-800 hover:text-white'
            }`}
          >
            <item.icon size={20} className={view === item.id ? 'text-indigo-200' : 'text-slate-500 group-hover:text-white transition-colors'} />
            <span className="hidden md:block font-medium">{item.label}</span>
            {view === item.id && <div className="ml-auto w-1.5 h-1.5 rounded-full bg-white hidden md:block"></div>}
          </button>
        ))}
      </nav>

      <div className="p-4 border-t border-slate-800">
        <div className="flex items-center gap-3 text-slate-400 text-xs px-2">
          <div className="w-2 h-2 rounded-full bg-green-500 animate-pulse shadow-[0_0_8px_rgba(34,197,94,0.6)]"></div>
          <span className="hidden md:block font-medium opacity-80">Sistema Online</span>
        </div>
      </div>
    </aside>
  );
};