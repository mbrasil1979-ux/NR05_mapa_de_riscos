import React from 'react';
import { Info } from 'lucide-react';

export const MatrixHelper: React.FC = () => (
  <div className="bg-white p-4 rounded-xl shadow-sm border border-slate-200 mb-6">
    <h4 className="font-bold text-slate-700 mb-3 flex items-center gap-2 text-sm uppercase tracking-wide">
      <Info size={16} className="text-indigo-500" /> Matriz de Decisão (CIPA/NR-05)
    </h4>
    <div className="grid grid-cols-4 gap-1 text-center text-xs">
      <div className="font-semibold text-slate-400 self-center">Grav \ Freq</div>
      <div className="font-semibold text-slate-600 self-end pb-1">Baixa</div>
      <div className="font-semibold text-slate-600 self-end pb-1">Média</div>
      <div className="font-semibold text-slate-600 self-end pb-1">Alta</div>
      
      <div className="font-semibold text-slate-600 self-center text-right pr-2">Leve</div>
      <div className="bg-green-100 text-green-800 p-1.5 rounded font-medium">Peq.</div>
      <div className="bg-green-100 text-green-800 p-1.5 rounded font-medium">Peq.</div>
      <div className="bg-yellow-100 text-yellow-800 p-1.5 rounded font-medium">Méd.</div>

      <div className="font-semibold text-slate-600 self-center text-right pr-2">Mod.</div>
      <div className="bg-green-100 text-green-800 p-1.5 rounded font-medium">Peq.</div>
      <div className="bg-yellow-100 text-yellow-800 p-1.5 rounded font-medium">Méd.</div>
      <div className="bg-red-100 text-red-800 p-1.5 rounded font-medium">Grd.</div>

      <div className="font-semibold text-slate-600 self-center text-right pr-2">Grave</div>
      <div className="bg-yellow-100 text-yellow-800 p-1.5 rounded font-medium">Méd.</div>
      <div className="bg-red-100 text-red-800 p-1.5 rounded font-medium">Grd.</div>
      <div className="bg-red-100 text-red-800 p-1.5 rounded font-medium">Grd.</div>
    </div>
  </div>
);