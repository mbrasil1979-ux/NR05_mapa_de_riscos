import React from 'react';
import { PlusCircle, ClipboardList } from 'lucide-react';
import { AssessmentData, RiskGroupId } from '../types';
import { RiskCircle } from '../components/RiskCircle';
import { MatrixHelper } from '../components/MatrixHelper';
import { BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer, Cell } from 'recharts';
import { RISK_GROUPS } from '../constants';

interface DashboardViewProps {
  assessments: AssessmentData[];
  onNew: () => void;
  loading: boolean;
}

export const DashboardView: React.FC<DashboardViewProps> = ({ assessments, onNew, loading }) => {
  const assessmentsBySector = assessments.reduce((acc, curr) => {
    const sector = curr.sector || 'Outros';
    if (!acc[sector]) acc[sector] = [];
    acc[sector].push(curr);
    return acc;
  }, {} as Record<string, AssessmentData[]>);

  // Prepare data for Recharts
  const chartData = Object.keys(RISK_GROUPS).map((key) => {
    const groupId = key as RiskGroupId;
    return {
      name: RISK_GROUPS[groupId].label.split('-')[1].trim(),
      count: assessments.filter(a => a.riskGroup === groupId).length,
      color: RISK_GROUPS[groupId].hex
    };
  });

  return (
    <div className="space-y-8 animate-fadeIn">
      {/* Header */}
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
        <div>
          <h2 className="text-3xl font-bold text-slate-800 tracking-tight">Mapa de Riscos Digital</h2>
          <p className="text-slate-500 mt-1">Visão consolidada em tempo real dos perigos no local de trabalho.</p>
        </div>
        <button 
          onClick={onNew}
          className="bg-indigo-600 hover:bg-indigo-700 text-white px-5 py-2.5 rounded-xl shadow-md shadow-indigo-200 flex items-center gap-2 transition-all transform hover:-translate-y-0.5"
        >
          <PlusCircle size={20} /> Adicionar Risco
        </button>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        {/* Main Map Area */}
        <div className="lg:col-span-2 space-y-6">
          
          {Object.keys(assessmentsBySector).length === 0 && !loading && (
            <div className="text-center py-24 bg-white rounded-2xl border-2 border-dashed border-slate-200">
              <div className="bg-indigo-50 text-indigo-600 w-20 h-20 rounded-full flex items-center justify-center mx-auto mb-6">
                <ClipboardList size={40} />
              </div>
              <h3 className="text-xl font-bold text-slate-800 mb-2">Nenhum risco mapeado ainda</h3>
              <p className="text-slate-500 mb-6 max-w-sm mx-auto">Comece realizando um levantamento do setor para identificar perigos potenciais.</p>
              <button onClick={onNew} className="text-indigo-600 font-bold hover:text-indigo-800 hover:underline">
                Criar primeira avaliação
              </button>
            </div>
          )}

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {Object.entries(assessmentsBySector).map(([sector, riskData]) => {
              const risks = riskData as AssessmentData[];
              return (
                <div key={sector} className="bg-white rounded-2xl shadow-sm border border-slate-200 overflow-hidden flex flex-col hover:shadow-md transition-shadow">
                  <div className="bg-slate-50 px-5 py-4 border-b border-slate-100 flex justify-between items-center">
                    <h3 className="font-bold text-slate-700 truncate text-lg" title={sector}>{sector}</h3>
                    <span className="text-xs font-bold bg-white px-2.5 py-1 rounded-full border border-slate-200 text-slate-500 shadow-sm">
                      {risks.length} {risks.length === 1 ? 'Risco' : 'Riscos'}
                    </span>
                  </div>
                  <div className="p-6 flex-1 relative min-h-[160px]">
                    <div className="absolute inset-0 opacity-[0.03] bg-[radial-gradient(#4f46e5_1px,transparent_1px)] [background-size:16px_16px]"></div>
                    <div className="relative z-10 flex flex-wrap gap-4 items-center justify-center h-full">
                        {risks.map((risk, idx) => (
                          <div key={idx} className="group relative cursor-help">
                            <RiskCircle group={risk.riskGroup} size={risk.riskSize} />
                            {/* Tooltip */}
                            <div className="absolute bottom-full left-1/2 -translate-x-1/2 mb-3 w-56 bg-slate-800 text-white text-xs p-3 rounded-lg shadow-xl opacity-0 group-hover:opacity-100 transition-opacity pointer-events-none z-20 scale-95 group-hover:scale-100 origin-bottom">
                                <p className="font-bold mb-1 text-indigo-200 border-b border-slate-600 pb-1">{risk.riskGroup.toUpperCase()}</p>
                                <p className="font-medium mb-2 leading-relaxed">{risk.description}</p>
                                <div className="flex justify-between text-[10px] opacity-70">
                                  <span>Freq: {risk.frequency}</span>
                                  <span>Grav: {risk.severity}</span>
                                </div>
                                <div className="absolute bottom-0 left-1/2 -translate-x-1/2 translate-y-1 w-2 h-2 bg-slate-800 rotate-45"></div>
                            </div>
                          </div>
                        ))}
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        </div>

        {/* Sidebar Widgets */}
        <div className="space-y-6">
          <MatrixHelper />
          
          <div className="bg-white p-6 rounded-xl border border-slate-200 shadow-sm">
            <h4 className="font-bold text-slate-700 mb-6 text-sm uppercase tracking-wide">Distribuição de Riscos</h4>
            <div className="h-64 w-full">
              <ResponsiveContainer width="100%" height="100%">
                <BarChart data={chartData} layout="vertical" margin={{ left: 10 }}>
                  <XAxis type="number" hide />
                  <YAxis dataKey="name" type="category" width={80} tick={{fontSize: 11}} axisLine={false} tickLine={false} />
                  <Tooltip 
                    cursor={{fill: 'transparent'}}
                    contentStyle={{ borderRadius: '8px', border: 'none', boxShadow: '0 4px 6px -1px rgb(0 0 0 / 0.1)' }}
                  />
                  <Bar dataKey="count" radius={[0, 4, 4, 0]} barSize={20}>
                    {chartData.map((entry, index) => (
                      <Cell key={`cell-${index}`} fill={entry.color} />
                    ))}
                  </Bar>
                </BarChart>
              </ResponsiveContainer>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};