import React from 'react';
import { Printer, Trash2, FileText } from 'lucide-react';
import { dbService } from '../services/firebase';
import { AssessmentData } from '../types';
import { RISK_GROUPS } from '../constants';

interface ReportViewProps {
  assessments: AssessmentData[];
}

export const ReportView: React.FC<ReportViewProps> = ({ assessments }) => {
  
  const handlePrint = () => {
    window.print();
  };

  const handleDelete = async (id?: string) => {
    if (!id) return;
    if (!window.confirm("Tem certeza que deseja excluir permanentemente este registro?")) return;
    try {
      await dbService.remove('cipa_assessments', id);
    } catch (error) {
      console.error("Error removing document: ", error);
    }
  };

  return (
    <div className="bg-white rounded-none md:rounded-2xl shadow-none md:shadow-sm border-0 md:border border-slate-200 overflow-hidden animate-fadeIn">
      <div className="p-6 border-b border-slate-200 flex flex-col md:flex-row justify-between items-start md:items-center gap-4 no-print bg-slate-50">
        <div>
          <h2 className="text-2xl font-bold text-slate-800 flex items-center gap-2">
            <FileText className="text-indigo-600" /> Relatório de Auditoria
          </h2>
          <p className="text-slate-500 text-sm">Documentação de Conformidade NR-05.</p>
        </div>
        <button 
          onClick={handlePrint}
          className="bg-slate-800 hover:bg-slate-900 text-white px-4 py-2 rounded-lg shadow-sm flex items-center gap-2 transition-colors"
        >
          <Printer size={18} /> Imprimir / Exportar PDF
        </button>
      </div>

      <div className="overflow-x-auto p-0 md:p-8 print:p-0">
        <div className="hidden print:block mb-8 text-center">
           <h1 className="text-3xl font-bold uppercase text-black tracking-wider mb-2">Relatório Técnico de Riscos</h1>
           <p className="text-sm text-gray-600 uppercase tracking-widest">Comissão Interna de Prevenção de Acidentes (CIPA)</p>
           <div className="mt-6 border-b-2 border-black w-full"></div>
        </div>

        <table className="w-full text-left text-sm border-collapse">
          <thead>
            <tr className="bg-slate-50 border-b-2 border-slate-200 print:bg-gray-100 print:border-black">
              <th className="p-4 font-bold text-slate-700 w-24">Data</th>
              <th className="p-4 font-bold text-slate-700 w-32">Setor</th>
              <th className="p-4 font-bold text-slate-700 w-40">Grupo de Risco</th>
              <th className="p-4 font-bold text-slate-700">Descrição do Perigo</th>
              <th className="p-4 font-bold text-slate-700 text-center w-24">Nível</th>
              <th className="p-4 font-bold text-slate-700 w-1/4">Controles</th>
              <th className="p-4 font-bold text-slate-700 no-print w-16 text-right">Ação</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-100 print:divide-gray-300">
            {assessments.map((item) => (
              <tr key={item.id} className="hover:bg-slate-50 print:hover:bg-transparent print-break-inside-avoid">
                <td className="p-4 text-slate-600 align-top text-xs">
                  {item.createdAt ? new Date(item.createdAt.seconds * 1000).toLocaleDateString('pt-BR') : new Date().toLocaleDateString('pt-BR')}
                </td>
                <td className="p-4 font-bold text-slate-800 align-top">{item.sector}</td>
                <td className="p-4 align-top">
                  <div className="flex items-center gap-2">
                    <span className={`w-2.5 h-2.5 rounded-full ${RISK_GROUPS[item.riskGroup]?.color}`}></span>
                    <span className="text-slate-600 font-medium">{RISK_GROUPS[item.riskGroup]?.label.split('-')[1]}</span>
                  </div>
                </td>
                <td className="p-4 text-slate-600 align-top leading-relaxed">{item.description}</td>
                <td className="p-4 text-center align-top">
                  <span className={`inline-block px-2.5 py-0.5 rounded-md text-[10px] uppercase font-bold border tracking-wide ${
                    item.riskSize === 'Grande' ? 'bg-red-50 text-red-700 border-red-200' :
                    item.riskSize === 'Médio' ? 'bg-yellow-50 text-yellow-700 border-yellow-200' :
                    'bg-green-50 text-green-700 border-green-200'
                  }`}>
                    {item.riskSize}
                  </span>
                </td>
                <td className="p-4 text-slate-600 align-top text-xs whitespace-pre-line">{item.controls || "-"}</td>
                <td className="p-4 text-right no-print align-top">
                  <button 
                    onClick={() => handleDelete(item.id)}
                    className="text-slate-400 hover:text-red-600 p-2 rounded-lg hover:bg-red-50 transition-colors"
                    title="Excluir registro"
                  >
                    <Trash2 size={16} />
                  </button>
                </td>
              </tr>
            ))}
             {assessments.length === 0 && (
              <tr>
                <td colSpan={7} className="p-12 text-center text-slate-400 italic bg-slate-50 border-b border-slate-200">
                  Nenhum registro encontrado para o relatório.
                </td>
              </tr>
            )}
          </tbody>
        </table>

        <div className="hidden print:flex mt-20 justify-between text-xs text-black pt-8 border-t border-black">
            <div className="text-center w-64">
               <p className="mb-8">_______________________________</p>
               <p className="font-bold uppercase">Representante da CIPA</p>
            </div>
            <div className="text-center w-64">
               <p className="mb-8">_______________________________</p>
               <p className="font-bold uppercase">SESMT / Gestão</p>
            </div>
        </div>
      </div>
    </div>
  );
};