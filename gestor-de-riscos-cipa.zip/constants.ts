import { RiskGroupDef, GuideSection, RiskGroupId, RiskSize, Frequency, Severity } from './types';

export const RISK_GROUPS: Record<RiskGroupId, RiskGroupDef> = {
  fisico: { id: 'fisico', label: 'Grupo 1 - Físico', color: 'bg-green-500', text: 'text-green-700', border: 'border-green-200', hex: '#22c55e', iconColor: 'bg-green-500' },
  quimico: { id: 'quimico', label: 'Grupo 2 - Químico', color: 'bg-red-500', text: 'text-red-700', border: 'border-red-200', hex: '#ef4444', iconColor: 'bg-red-500' },
  biologico: { id: 'biologico', label: 'Grupo 3 - Biológico', color: 'bg-yellow-800', text: 'text-yellow-900', border: 'border-yellow-700', hex: '#854d0e', iconColor: 'bg-yellow-800' },
  ergonomico: { id: 'ergonomico', label: 'Grupo 4 - Ergonômico', color: 'bg-yellow-400', text: 'text-yellow-800', border: 'border-yellow-200', hex: '#facc15', iconColor: 'bg-yellow-400' },
  acidente: { id: 'acidente', label: 'Grupo 5 - Acidentes', color: 'bg-blue-500', text: 'text-blue-700', border: 'border-blue-200', hex: '#3b82f6', iconColor: 'bg-blue-500' },
};

export const INTENSITY_MATRIX: Record<Severity, Record<Frequency, RiskSize>> = {
  'Leve': { 'Baixa': 'Pequeno', 'Média': 'Pequeno', 'Alta': 'Médio' },
  'Moderada': { 'Baixa': 'Pequeno', 'Média': 'Médio', 'Alta': 'Grande' },
  'Grave': { 'Baixa': 'Médio', 'Média': 'Grande', 'Alta': 'Grande' }
};

export const SIZE_STYLES: Record<RiskSize, string> = {
  'Pequeno': 'w-4 h-4',
  'Médio': 'w-8 h-8',
  'Grande': 'w-12 h-12'
};

export const RISK_GUIDE_DATA: GuideSection[] = [
  {
    id: 'fisico',
    title: 'Grupo 1 - Riscos Físicos',
    colorClass: 'bg-green-50 border-green-200 text-green-800',
    iconColor: 'bg-green-500',
    description: 'Formas de energia a que o trabalhador pode estar exposto acima dos limites de tolerância.',
    examples: [
      'Ruído Contínuo ou Intermitente', 
      'Ruído de Impacto',
      'Calor Excessivo', 
      'Frio Excessivo', 
      'Vibrações', 
      'Radiações Ionizantes e Não-Ionizantes', 
      'Umidade', 
      'Pressões Anormais'
    ]
  },
  {
    id: 'quimico',
    title: 'Grupo 2 - Riscos Químicos',
    colorClass: 'bg-red-50 border-red-200 text-red-800',
    iconColor: 'bg-red-500',
    description: 'Substâncias, compostos ou produtos que podem penetrar no organismo pela via respiratória ou contato.',
    examples: [
      'Poeiras Minerais e Vegetais', 
      'Fumos Metálicos', 
      'Névoas e Neblinas', 
      'Gases e Vapores', 
      'Produtos Químicos em geral'
    ]
  },
  {
    id: 'biologico',
    title: 'Grupo 3 - Riscos Biológicos',
    colorClass: 'bg-amber-50 border-amber-200 text-amber-900',
    iconColor: 'bg-yellow-800',
    description: 'Microrganismos e parasitas que podem causar doenças.',
    examples: [
      'Vírus e Bactérias', 
      'Fungos e Parasitas', 
      'Bacilos', 
      'Lixo Urbano ou Hospitalar', 
      'Fluidos Corporais'
    ]
  },
  {
    id: 'ergonomico',
    title: 'Grupo 4 - Riscos Ergonômicos',
    colorClass: 'bg-yellow-50 border-yellow-200 text-yellow-800',
    iconColor: 'bg-yellow-400',
    description: 'Fatores psicofisiológicos que causam desconforto ou afetam a saúde.',
    examples: [
      'Esforço físico intenso', 
      'Levantamento manual de peso', 
      'Postura inadequada', 
      'Trabalho em turno/noturno', 
      'Monotonia e Repetitividade'
    ],
    psychosocial: [
      'Assédio Moral ou Sexual',
      'Estresse Ocupacional',
      'Cobrança excessiva de metas',
      'Jornadas prolongadas'
    ]
  },
  {
    id: 'acidente',
    title: 'Grupo 5 - Riscos de Acidentes',
    colorClass: 'bg-blue-50 border-blue-200 text-blue-800',
    iconColor: 'bg-blue-500',
    description: 'Qualquer fator que coloque o trabalhador em situação vulnerável a acidentes.',
    examples: [
      'Máquinas sem proteção', 
      'Arranjo físico inadequado', 
      'Ferramentas defeituosas', 
      'Iluminação inadequada', 
      'Eletricidade', 
      'Risco de Incêndio/Explosão', 
      'Trabalho em Altura'
    ]
  }
];
