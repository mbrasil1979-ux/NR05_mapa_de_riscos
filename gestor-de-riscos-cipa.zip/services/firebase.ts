import { initializeApp, FirebaseApp } from 'firebase/app';
import { getAuth, Auth } from 'firebase/auth';
import { 
  getFirestore, 
  Firestore, 
  collection, 
  addDoc, 
  deleteDoc, 
  doc, 
  query, 
  onSnapshot,
  serverTimestamp as firebaseServerTimestamp,
  Timestamp
} from 'firebase/firestore';

// Configuração via Variáveis de Ambiente ou Fallback seguro
const firebaseConfig = {
  apiKey: process.env.FIREBASE_API_KEY || "SUA_API_KEY_AQUI", 
  authDomain: process.env.FIREBASE_AUTH_DOMAIN || "seu-projeto.firebaseapp.com",
  projectId: process.env.FIREBASE_PROJECT_ID || "seu-projeto",
  storageBucket: process.env.FIREBASE_STORAGE_BUCKET || "seu-projeto.appspot.com",
  messagingSenderId: process.env.FIREBASE_MESSAGING_SENDER_ID || "123456...",
  appId: process.env.FIREBASE_APP_ID || "1:123456..."
};

let app: FirebaseApp | undefined;
let auth: Auth | undefined;
let db: Firestore | undefined;

// Verifica se a configuração é válida (não é o placeholder padrão)
export const isFirebaseConfigured = 
  firebaseConfig.apiKey !== "SUA_API_KEY_AQUI" && 
  !firebaseConfig.apiKey.includes("SUA_API_KEY");

try {
  if (isFirebaseConfigured) {
    app = initializeApp(firebaseConfig);
    auth = getAuth(app);
    db = getFirestore(app);
  } else {
    console.warn("⚠️ Firebase não configurado. Usando LocalStorage para persistência de dados.");
  }
} catch (error) {
  console.error("Firebase initialization error:", error);
}

export { app, auth, db };

// --- SERVIÇO DE ABSTRAÇÃO DE BANCO DE DADOS ---
// Permite que o app funcione com Firebase OU LocalStorage sem mudar o código das views

const STORAGE_KEY = 'cipa_assessments_local_db';

// Gera ID aleatório para LocalStorage
const generateId = () => Math.random().toString(36).substr(2, 9);

export const dbService = {
  // ADICIONAR DOCUMENTO
  add: async (collectionName: string, data: any) => {
    if (isFirebaseConfigured && db && auth?.currentUser) {
      return addDoc(collection(db, collectionName), {
        ...data,
        userId: auth.currentUser.uid,
        createdAt: firebaseServerTimestamp()
      });
    } else {
      // Fallback LocalStorage
      const currentData = JSON.parse(localStorage.getItem(STORAGE_KEY) || '[]');
      const newItem = {
        id: generateId(),
        ...data,
        userId: 'local-user',
        createdAt: { seconds: Math.floor(Date.now() / 1000), nanoseconds: 0 }, // Simula Timestamp do Firestore
        isLocal: true
      };
      localStorage.setItem(STORAGE_KEY, JSON.stringify([...currentData, newItem]));
      // Dispara evento para atualizar a UI
      window.dispatchEvent(new Event('local-storage-update'));
      return { id: newItem.id };
    }
  },

  // REMOVER DOCUMENTO
  remove: async (collectionName: string, id: string) => {
    if (isFirebaseConfigured && db) {
      return deleteDoc(doc(db, collectionName, id));
    } else {
      // Fallback LocalStorage
      const currentData = JSON.parse(localStorage.getItem(STORAGE_KEY) || '[]');
      const newData = currentData.filter((item: any) => item.id !== id);
      localStorage.setItem(STORAGE_KEY, JSON.stringify(newData));
      window.dispatchEvent(new Event('local-storage-update'));
    }
  },

  // SUBSCREVER A MUDANÇAS (REAL-TIME)
  subscribe: (collectionName: string, callback: (data: any[]) => void) => {
    if (isFirebaseConfigured && db) {
      const q = query(collection(db, collectionName));
      return onSnapshot(q, (snapshot) => {
        const docs = snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() }));
        callback(docs);
      }, (error) => {
        console.error("Erro Firestore:", error);
        callback([]);
      });
    } else {
      // Fallback LocalStorage (Simula Real-time com EventListener)
      const loadLocal = () => {
        const data = JSON.parse(localStorage.getItem(STORAGE_KEY) || '[]');
        callback(data);
      };
      
      loadLocal(); // Carga inicial
      
      window.addEventListener('local-storage-update', loadLocal);
      // Retorna função de unsubscribe
      return () => window.removeEventListener('local-storage-update', loadLocal);
    }
  }
};