import React, { useState, useEffect } from 'react';
import { signInAnonymously, onAuthStateChanged, User } from 'firebase/auth';
import { auth, isFirebaseConfigured, dbService } from './services/firebase';
import { AssessmentData } from './types';
import { Sidebar } from './components/Sidebar';
import { DashboardView } from './views/DashboardView';
import { NewAssessmentView } from './views/NewAssessmentView';
import { GuideView } from './views/GuideView';
import { ReportView } from './views/ReportView';
import { Database, CloudOff } from 'lucide-react';

export default function App() {
  const [user, setUser] = useState<User | null>(null);
  const [view, setView] = useState('dashboard');
  const [assessments, setAssessments] = useState<AssessmentData[]>([]);
  const [loading, setLoading] = useState(true);

  // Auth
  useEffect(() => {
    if (!isFirebaseConfigured || !auth) {
      // No modo local, não precisamos de auth real, mas paramos o loading
      if (!isFirebaseConfigured) setLoading(false);
      return;
    }

    const initAuth = async () => {
      try {
        await signInAnonymously(auth);
      } catch (e) {
        console.error("Auth error:", e);
      }
    };
    initAuth();
    
    const unsubscribe = onAuthStateChanged(auth, (currentUser) => {
      setUser(currentUser);
    });
    return () => unsubscribe();
  }, []);

  // Data Fetching (Abstraído via dbService)
  useEffect(() => {
    // Se estiver configurado mas sem usuário, aguarda. Se não configurado, prossegue com LocalStorage.
    if (isFirebaseConfigured && !user) return;

    setLoading(true);
    
    // A função subscribe retorna o unsubscribe
    const unsubscribe = dbService.subscribe('cipa_assessments', (data) => {
      // Ordenação
      const sortedData = data.sort((a, b) => {
        const timeA = a.createdAt?.seconds || 0;
        const timeB = b.createdAt?.seconds || 0;
        return timeB - timeA;
      });
      
      setAssessments(sortedData as AssessmentData[]);
      setLoading(false);
    });

    return () => {
      if (typeof unsubscribe === 'function') unsubscribe();
    };
  }, [user]);

  if (loading) {
    return (
      <div className="min-h-screen bg-slate-50 flex items-center justify-center">
        <div className="flex flex-col items-center">
          <div className="w-12 h-12 border-4 border-indigo-200 border-t-indigo-600 rounded-full animate-spin mb-4"></div>
          <div className="text-indigo-600 font-medium animate-pulse">Carregando Sistema...</div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-slate-50 font-sans text-slate-900 flex overflow-hidden">
      <Sidebar view={view} setView={setView} />

      <main className="flex-1 p-4 md:p-8 ml-20 md:ml-0 overflow-y-auto h-screen scroll-smooth">
        {/* Mobile Header */}
        <div className="md:hidden mb-6 flex items-center justify-between">
           <h1 className="text-xl font-bold text-slate-800">Gestor de Riscos</h1>
        </div>
        
        {!isFirebaseConfigured && (
           <div className="mb-6 bg-indigo-50 border border-indigo-200 text-indigo-800 px-4 py-3 rounded-lg text-sm flex items-center gap-3 shadow-sm animate-fadeIn">
              <div className="p-1.5 bg-indigo-100 rounded-full">
                <Database size={16} className="text-indigo-600" />
              </div>
              <div>
                <span className="font-bold">Modo Local Ativo:</span> Firebase não configurado. Os dados estão sendo salvos no navegador (LocalStorage).
              </div>
           </div>
        )}

        <div className="max-w-7xl mx-auto">
          {view === 'dashboard' && <DashboardView assessments={assessments} onNew={() => setView('new')} loading={loading} />}
          {view === 'new' && <NewAssessmentView onCancel={() => setView('dashboard')} onSuccess={() => setView('dashboard')} />}
          {view === 'guide' && <GuideView />}
          {view === 'report' && <ReportView assessments={assessments} />}
        </div>
      </main>
    </div>
  );
}