import React, { useState, useMemo } from 'react';
import { PlusCircle, Save, Sparkles, AlertCircle } from 'lucide-react';
import { dbService } from '../services/firebase';
import { AssessmentData, RiskGroupId } from '../types';
import { RISK_GROUPS, INTENSITY_MATRIX } from '../constants';
import { RiskCircle } from '../components/RiskCircle';
import { suggestControlMeasures } from '../services/gemini';

interface NewAssessmentViewProps {
  onCancel: () => void;
  onSuccess: () => void;
}

export const NewAssessmentView: React.FC<NewAssessmentViewProps> = ({ onCancel, onSuccess }) => {
  const [formData, setFormData] = useState<AssessmentData>({
    sector: '',
    description: '',
    riskGroup: 'fisico',
    frequency: 'Média',
    severity: 'Moderada',
    controls: '',
    responsible: ''
  });
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [isAiLoading, setIsAiLoading] = useState(false);

  const calculatedRiskSize = useMemo(() => {
    return INTENSITY_MATRIX[formData.severity][formData.frequency];
  }, [formData.severity, formData.frequency]);

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>) => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: value }));
  };

  const handleGroupSelect = (id: string) => {
    setFormData(prev => ({ ...prev, riskGroup: id as RiskGroupId }));
  };

  const handleAiSuggest = async () => {
    if (!formData.description || !formData.sector) {
      alert("Por favor, preencha Setor e Descrição primeiro.");
      return;
    }
    setIsAiLoading(true);
    const suggestions = await suggestControlMeasures(formData.description, formData.sector, formData.riskGroup);
    
    // Append suggestions to existing controls if any
    setFormData(prev => ({
      ...prev,
      controls: prev.controls ? `${prev.controls}\n\nSugestões IA:\n${suggestions}` : suggestions
    }));
    setIsAiLoading(false);
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmitting(true);
    
    try {
      // Usa o dbService que gerencia Firebase ou LocalStorage automaticamente
      await dbService.add('cipa_assessments', {
        ...formData,
        riskSize: calculatedRiskSize,
        status: 'Pendente'
      });
      onSuccess();
    } catch (error) {
      console.error("Error adding document: ", error);
      alert("Erro ao salvar dados.");
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className="max-w-3xl mx-auto bg-white rounded-2xl shadow-sm border border-slate-200 overflow-hidden animate-fadeIn">
      <div className="bg-slate-50 px-8 py-6 border-b border-slate-100 flex items-center gap-3">
        <div className="p-2 bg-white rounded-lg border border-slate-200 shadow-sm">
          <PlusCircle className="text-indigo-600" size={24} />
        </div>
        <div>
           <h2 className="text-xl font-bold text-slate-800">Nova Avaliação de Risco</h2>
           <p className="text-sm text-slate-500">Documentar um novo perigo identificado no local de trabalho.</p>
        </div>
      </div>

      <form onSubmit={handleSubmit} className="p-8 space-y-8">
        
        {/* Basic Info */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <div className="space-y-2">
            <label className="text-sm font-semibold text-slate-700">Setor / Área</label>
            <input 
              required
              type="text" 
              name="sector"
              value={formData.sector}
              onChange={handleInputChange}
              placeholder="Ex: Soldagem, Almoxarifado..."
              className="w-full px-4 py-2.5 bg-slate-50 border border-slate-200 rounded-lg focus:bg-white focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500 outline-none transition-all"
            />
          </div>
          <div className="space-y-2">
            <label className="text-sm font-semibold text-slate-700">Responsável</label>
            <input 
              required
              type="text" 
              name="responsible"
              value={formData.responsible}
              onChange={handleInputChange}
              placeholder="Nome do avaliador"
              className="w-full px-4 py-2.5 bg-slate-50 border border-slate-200 rounded-lg focus:bg-white focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500 outline-none transition-all"
            />
          </div>
        </div>

        {/* Risk Group Selection */}
        <div className="space-y-3">
          <label className="text-sm font-semibold text-slate-700">Classificação de Risco</label>
          <div className="grid grid-cols-2 md:grid-cols-5 gap-3">
            {Object.entries(RISK_GROUPS).map(([key, group]) => (
              <button
                key={key}
                type="button"
                onClick={() => handleGroupSelect(key)}
                className={`p-3 text-xs font-bold rounded-xl border transition-all flex flex-col items-center gap-2 ${
                  formData.riskGroup === key 
                    ? `${group.border} ${group.color} text-white shadow-md scale-105` 
                    : 'border-slate-200 bg-white text-slate-500 hover:bg-slate-50 hover:border-slate-300'
                }`}
              >
                <div className={`w-3 h-3 rounded-full ${formData.riskGroup === key ? 'bg-white' : group.color}`}></div>
                {group.label.split(' - ')[1]}
              </button>
            ))}
          </div>
        </div>

        {/* Description & AI */}
        <div className="space-y-2">
          <div className="flex justify-between items-center">
             <label className="text-sm font-semibold text-slate-700">Descrição do Perigo</label>
          </div>
          <textarea 
            required
            name="description"
            value={formData.description}
            onChange={handleInputChange}
            placeholder="Descreva a fonte do perigo potencial..."
            className="w-full p-4 bg-slate-50 border border-slate-200 rounded-lg h-24 focus:bg-white focus:ring-2 focus:ring-indigo-500 outline-none transition-all resize-none"
          />
        </div>

        {/* Matrix Calculator */}
        <div className="p-6 bg-slate-50 rounded-xl border border-slate-200">
          <h3 className="text-sm font-bold text-slate-700 mb-4 flex items-center gap-2">
            <AlertCircle size={16} className="text-slate-400"/> Calculadora de Gravidade
          </h3>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6 items-center">
            <div className="space-y-2">
              <label className="text-xs font-bold text-slate-500 uppercase tracking-wider">Frequência</label>
              <div className="relative">
                <select 
                  name="frequency"
                  value={formData.frequency}
                  onChange={handleInputChange}
                  className="w-full p-2.5 border border-slate-300 rounded-lg bg-white appearance-none cursor-pointer hover:border-indigo-400 focus:ring-2 focus:ring-indigo-500 outline-none"
                >
                  <option>Baixa</option>
                  <option>Média</option>
                  <option>Alta</option>
                </select>
                <div className="pointer-events-none absolute inset-y-0 right-0 flex items-center px-2 text-slate-700">
                  <svg className="fill-current h-4 w-4" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20"><path d="M9.293 12.95l.707.707L15.657 8l-1.414-1.414L10 10.828 5.757 6.586 4.343 8z"/></svg>
                </div>
              </div>
            </div>

            <div className="space-y-2">
              <label className="text-xs font-bold text-slate-500 uppercase tracking-wider">Gravidade</label>
              <div className="relative">
                <select 
                  name="severity"
                  value={formData.severity}
                  onChange={handleInputChange}
                  className="w-full p-2.5 border border-slate-300 rounded-lg bg-white appearance-none cursor-pointer hover:border-indigo-400 focus:ring-2 focus:ring-indigo-500 outline-none"
                >
                  <option>Leve</option>
                  <option>Moderada</option>
                  <option>Grave</option>
                </select>
                <div className="pointer-events-none absolute inset-y-0 right-0 flex items-center px-2 text-slate-700">
                  <svg className="fill-current h-4 w-4" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20"><path d="M9.293 12.95l.707.707L15.657 8l-1.414-1.414L10 10.828 5.757 6.586 4.343 8z"/></svg>
                </div>
              </div>
            </div>

            <div className="flex flex-col items-center justify-center p-3 bg-white rounded-xl border border-slate-200 shadow-sm">
              <span className="text-[10px] uppercase font-bold text-slate-400 mb-2">Risco Calculado</span>
              <div className="flex items-center gap-3">
                <RiskCircle group={formData.riskGroup} size={calculatedRiskSize} />
                <span className="font-bold text-slate-800 text-lg">{calculatedRiskSize}</span>
              </div>
            </div>
          </div>
        </div>

        {/* Controls with AI */}
        <div className="space-y-2">
          <div className="flex justify-between items-end">
             <label className="text-sm font-semibold text-slate-700">Medidas de Controle</label>
             <button
                type="button"
                onClick={handleAiSuggest}
                disabled={isAiLoading}
                className="text-xs font-medium text-indigo-600 hover:text-indigo-800 hover:bg-indigo-50 px-3 py-1.5 rounded-full transition-colors flex items-center gap-1.5 border border-indigo-100"
              >
                {isAiLoading ? (
                  <div className="w-3 h-3 border-2 border-indigo-600 border-t-transparent rounded-full animate-spin"></div>
                ) : (
                  <Sparkles size={14} />
                )}
                {isAiLoading ? 'Pensando...' : 'Sugestões IA'}
              </button>
          </div>
          <textarea 
            name="controls"
            value={formData.controls}
            onChange={handleInputChange}
            placeholder="Insira medidas ou use IA para gerar..."
            className="w-full p-4 bg-slate-50 border border-slate-200 rounded-lg h-32 focus:bg-white focus:ring-2 focus:ring-indigo-500 outline-none transition-all font-mono text-sm"
          />
        </div>

        {/* Actions */}
        <div className="flex justify-end gap-4 pt-6 border-t border-slate-100">
          <button 
            type="button" 
            onClick={onCancel}
            className="px-6 py-2.5 text-slate-600 font-medium hover:bg-slate-100 rounded-lg transition-colors"
          >
            Cancelar
          </button>
          <button 
            type="submit" 
            disabled={isSubmitting}
            className="px-8 py-2.5 bg-indigo-600 hover:bg-indigo-700 text-white font-semibold rounded-lg shadow-md shadow-indigo-200 hover:shadow-lg transition-all flex items-center gap-2 disabled:opacity-70 disabled:cursor-not-allowed"
          >
            {isSubmitting ? 'Salvando...' : <><Save size={18} /> Salvar Avaliação</>}
          </button>
        </div>
      </form>
    </div>
  );
};